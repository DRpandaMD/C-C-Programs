/*
 * options.h
 *
 * 	Created on: Feb 9, 2015
 *  Author: michaelzarate
 *  CSE220 SPRING 2015, Programming for Computer Engineering
 *  HomeWorkd Number: 3
 *  Estimated time :20 + hours
 */


#ifndef OPTIONS_H_
#define OPTIONS_H_

#include<stdio.h>
void options();


#endif /* OPTIONS_H_ */
