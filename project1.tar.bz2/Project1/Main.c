/*
 * Main.c
 *
 *  Created on: Mar 14, 2015
 *      Author: michaelzarate
 */

//array of car structures (add and delete) size 50
//sleep
// Cycle while CTRL ^ C
// calling the important function


#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include "Main.h"
#include "parseArgs.h"
#include "print.h"
#include "vehicles.h"



unsigned sleep(unsigned seconds);
void init();
void createNetwork();

volatile sig_atomic_t stop;

void inthand(int signum)
{
    stop = 1;
}

void init()
{
	//initilize the the linked list for activities

	//parseCmdLine( argc, *argv[], Args *opt); //calls the function to parse up the CmdLine arguments.
	//createNetwork(); //sets up the network
}

void createNetwork()
{
	//*head;
}

int main ( int argc, char *argv[] )
{
	//make a car pointer
	CAR *carPointer = NULL;
	Args *argPointer = NULL;
	Args * opt = NULL;
	parseCmdLine( argc, argv, opt);




	//unsigned  time = (double)1;
	signal(SIGINT, inthand);



//write the initit() function make these point somewhere


	while (!stop)
	{
		printf("loop\n"); //Call the update Run time from the rest of the program.
		updateNeighbors(carPointer, argPointer);
		updateValues(carPointer, argPointer);
		//printDetails(CAR *printPtr, Args *printOpt);
		sleep(opt->interval);
	}
	printf("exiting safely!\n");
	printf("System stopped.\n");

		return 0;

}
