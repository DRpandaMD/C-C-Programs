/*
 * Wall.cpp
 *
 *  Created on: Mar 30, 2015
 *      Author: michaelzarate
 */




#include <sstream>
#include <string>
#include "User.h"
#include "Wall.h"

using namespace std;

Wall::Wall(string, string&)
{
	&messageBuffer = string;

}

Wall::addMessage()
{

}
